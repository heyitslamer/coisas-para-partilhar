package routines;

import java.util.Date;

/*
 * {Category} UserDefined
 * 
 * 
 */
public class fazGrupo {

    /**
     * 
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * 
     * {example} helloExemple("world") # hello world !.
     */
    public static String fazG(Date dt) {
    	long idade = TalendDate.diffDate(TalendDate.getCurrentDate(), dt, "yyyy");
    	
    	if(idade < 10) {
    		return "Criança";
    	} else if(idade < 18) {
    		return "Adolescente";
    	} else if(idade < 40) {
    		return "Adulto";
    	} else if(idade < 60) {
    		return "Meia Idade";
    	} else {
    		return "Idoso";
    	}    
    }
}
