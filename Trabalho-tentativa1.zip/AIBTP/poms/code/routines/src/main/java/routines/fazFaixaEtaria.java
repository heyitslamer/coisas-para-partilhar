package routines;

import java.util.Date;

/*
 * {Category} UserDefined
 * 
 */
public class fazFaixaEtaria {

    /**
     * 
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
      * 
     * {example} helloExemple("world") # hello world !.
     */
    public static String fazFE(Date td) {
    	long idade = TalendDate.diffDate(TalendDate.getCurrentDate(), td, "yyyy");
    	
        if(idade < 10) {
        	return "00-10";
        } else if (idade < 20) {
        	return "10-20";
        } else if (idade < 30) {
        	return "20-30";
        } else if (idade < 40) {
        	return "30-40";
        } else if (idade < 50) {
        	return "40-50";
        } else if (idade < 60) {
        	return "50-60";
        } else if (idade < 70) {
        	return "60-70";
        } else if (idade < 80) {
        	return "70-80";
        } else if (idade < 90) {
        	return "80-90";
        } else if (idade < 100) {
        	return "90-100";
        } else {
        	return "Undef";
        }
    }
}
